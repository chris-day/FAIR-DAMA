# Embed the DAMA–FAIR Sankey diagram in Zensical

Package version: 1.2.0  
Diagram version: 1.1.0  
Author: Chris Day

Embed the standalone HTML page in an iframe to preserve hover highlighting, ribbon selection, FAIR IDs and short names, and the selected-link detail panel. The iframe keeps the diagram's JavaScript and styling separate from the documentation theme.

## 1. Copy the standalone diagram

Copy this package's `index.html` into your Zensical documentation directory and rename it `sankey-v1.1.0.html`:

```text
docs/
└── fair-alignment/
    ├── index.md
    └── sankey-v1.1.0.html
```

Use the packaged `index.html`, not `diagram-fragment.html`. The standalone page includes the styling and runtime required by the diagram. Diagram version 1.1.0 adds clickable document-section labels.

## 2. Create the Markdown page

Create `docs/fair-alignment/index.md` with the following content. Copy the iframe as raw HTML, outside a code block, in the destination page.

```markdown
---
title: DAMA and FAIR Alignment
---

# DAMA and FAIR Alignment

Explore the proposed relationships between the 11 DAMA core knowledge
areas and the 15 FAIR Data Principles.

Hover over a knowledge area to highlight its connections.
Select a ribbon to inspect its rationale and deliverables.

<iframe
  src="sankey-v1.1.0.html"
  title="Interactive DAMA knowledge areas and FAIR principles Sankey diagram"
  width="100%"
  height="1350"
  loading="lazy"
  style="border: 0; display: block;">
</iframe>

[Open the interactive diagram on its own](sankey-v1.1.0.html)

Each ribbon represents one proposed alignment, not alignment strength,
implementation maturity or demonstrated compliance.
```

This layout keeps the Markdown index page and the diagram in the same published directory. The relative iframe URL therefore works when the site is hosted under a project subpath, such as `/repository-name/fair-alignment/`.

The chart itself is approximately 1,100 pixels tall, plus its title, legend and selected-link details. Start with an iframe height of 1,350 pixels and adjust it after checking desktop and mobile layouts. The outer iframe has a fixed height; the standalone diagram responds to its available width.

## 3. Add Zensical navigation

Merge the following navigation entry into your existing `zensical.toml` configuration. Preserve your other navigation entries and do not create a second `[project]` table if one already exists.

```toml
[project]
nav = [
  { "Home" = "index.md" },
  { "DAMA and FAIR Alignment" = "fair-alignment/index.md" },
]
```

No diagram plugin or additional site-level JavaScript is needed for this embedding method. Keep the diagram HTML inside the documentation directory and ensure it is not excluded by your configuration.

## 4. Preview and verify

From the site project directory, run:

```shell
zensical serve
```

Open the alignment page and check:

- The diagram loads and shows all 11 knowledge areas and 15 FAIR principles.
- Hovering highlights the relevant connections.
- Selecting a ribbon displays its rationale and deliverables.
- FAIR IDs and their short names are visible.
- The direct-open link works.
- The page remains usable at mobile widths.
- The diagram works after navigating away and back.

Build the site for deployment with:

```shell
zensical build
```

## Material for MkDocs alternative

Use the same `docs/` layout and Markdown page. Add the navigation entry to `mkdocs.yml` instead:

```yaml
nav:
  - Home: index.md
  - DAMA and FAIR Alignment: fair-alignment/index.md
```

Preview and build with:

```shell
mkdocs serve
mkdocs build
```

The iframe loads its own document and initializes its own scripts. If you later integrate the diagram directly into the theme instead of using an iframe, account for Material's instant-navigation lifecycle through its `document$` observable.

## Runtime and hosting considerations

- **Internet access:** the supplied page loads D3.js, d3-sankey and viewer resources from external hosts. It is not an offline bundle.
- **Theme:** the diagram has its own appearance and does not automatically follow the documentation site's theme toggle.
- **Data:** all mapping data is embedded in the HTML. No server-side processing or data API is needed.
- **Search:** the iframe content is separate from the Markdown page; include explanatory text in the page for documentation search and accessibility.
- **Hosting policies:** if your site sets a Content Security Policy, it must allow the iframe. The diagram's external resources must also be accessible to visitors.
- **Offline deployment:** bundling dependencies locally requires adapting the standalone page and its resource policy; changing the iframe alone does not make the diagram offline-capable.

## References

- [Zensical configuration](https://zensical.org/docs/setup/basics/)
- [Zensical navigation](https://zensical.org/docs/setup/navigation/)
- [MkDocs file handling](https://www.mkdocs.org/user-guide/writing-your-docs/#file-layout)
- [Material for MkDocs JavaScript customization](https://squidfunk.github.io/mkdocs-material/customization/#additional-javascript)

## Configure clickable document sections

Knowledge-area and FAIR-principle labels open the matching document section in a new tab. By default, the package opens its included HTML reading copy. Ribbons still show rationale and deliverables.

For a published Zensical or Material for MkDocs site, pass the published document page URL using the `doc` query parameter. Use the generated page URL, not the `.md` source URL. Encode the value with `encodeURIComponent` if constructing it programmatically. For example, when the document is published at `/my-project/dama-segments/`:

```html
<iframe
  src="sankey-v1.1.0.html?doc=%2Fmy-project%2Fdama-segments%2F"
  title="Interactive DAMA and FAIR alignment with document links"
  width="100%"
  height="1350"
  style="border: 0; display: block;">
</iframe>
```

Replace `/my-project/dama-segments/` with your actual published page path. The standalone page resolves relative document URLs against its own URL. If you sandbox the outer embedding iframe, it must allow scripts, popups and popups escaping the sandbox for the new-tab document links to work.

`section-links.json` maps the 11 core knowledge-area names and 15 FAIR IDs to the document's existing heading anchors. Legacy name correspondences are intentional: Data Modeling & Design links to Data Development; Data Storage & Operations links to Data Operations Management; Metadata Management links to Meta-data Management. Keep the published headings consistent with document v1.17.0 or update the section anchors if you rename them. Check all 26 links after publishing, because a Markdown engine or slug configuration can generate different IDs.

To retain the included default document view, copy its HTML file and `assets/` directory beside the diagram. Alternatively, configure `doc` and publish the Markdown source through your documentation site.
