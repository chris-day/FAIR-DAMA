# DAMA–FAIR Sankey diagram

Version: 1.3.0  
Author: Chris Day  
Document version: 1.18.0

## Open

Extract the ZIP and open `index.html` in a modern browser. Internet access is required for D3 and viewer resources. Hover over a node or ribbon to highlight connections. Select a ribbon for rationale, provenance and activity references. Select an area/topic or FAIR-principle label to open its corresponding document section in a new tab.

## Scope and counts

The left side now contains the 11 core DMBOK2 knowledge areas plus **Big Data & Data Science** and **Data Handling Ethics**. These additions do not redefine the 11 core knowledge areas. Data Management Maturity Assessment has no assigned FAIR IDs and is not shown as a ribbon-bearing node.

There are **74 mappings** to the 15 FAIR principles:

- 51 direct and 10 enabling mappings from the original 11-area implementation-oriented proposal.
- 1 conditional direct and 10 indirect mappings for Big Data & Data Science, derived from its activity analysis.
- 2 indirect mappings for Data Handling Ethics, derived from its activity analysis.

The diagram therefore displays **52 direct** and **22 enabling/indirect** connections. An area can have the same FAIR principle in both categories where activities contribute differently. Each unique area–principle–alignment-type relationship is one ribbon with value one. Ribbon width measures mapping count, not strength, maturity, population or compliance.

These mapping bases are deliberately retained rather than silently converting the original diagram to the more conservative worksheet analysis. The basis is exposed in ribbon details and in `data.json`. New topic links aggregate their matching worksheet rows, with exact row ranges recorded in `activityEvidence`. All assignments are proposed; no implementation is asserted. Big Data's R1 mapping is conditional on resource-linked, accurate methodological descriptions. Ethics supplies no established direct principle IDs.

## Included files

- `index.html`: standalone interactive diagram.
- `diagram-fragment.html`: editable visualization source with embedded data.
- `data.json`: mappings, principle short names, basis and new activity evidence.
- `section-links.json`: 28 document destinations.
- `DAMA_Segments_High_Level_v1.18.0.md`: authoritative Markdown document.
- `DAMA_Segments_High_Level_v1.18.0.html`: portable reading copy with exact heading anchors.
- `assets/`: the document's source diagrams and its original, explicitly scoped static Sankey.
- `outputs/dama-20261116/DAMA-PDOC_FAIR-MASTER_2026-11-16_V3.xlsx`: updated source workbook.
- `README_ZENSICAL.md`: integration instructions for Zensical and Material for MkDocs.
- `manifest.json`: counts, versions and SHA-256 checksums.

The bundled document's overview still intentionally shows the original 11-area, 61-link implementation-proposal diagram. Version 1.3.0 of this interactive package expands that scope to 13 areas/topics; it does not alter the authoritative Markdown document. Editing `data.json` alone does not update the data embedded in either HTML file.

## Document links

By default, label links open the packaged HTML reading copy. To use a published document page, append a URL-encoded `doc` query parameter to the diagram URL, as described in `README_ZENSICAL.md`. Heading IDs can differ with Markdown renderer configuration: verify links after publication.

## Dependencies

D3.js 7.9.0 and d3-sankey 0.12.3 are loaded from jsDelivr. The standalone wrapper loads viewer resources remotely. No data API or server-side processing is used. The diagram has its own theme rather than inheriting the documentation site's theme toggle.

## Version history

- 1.3.0: Added Big Data & Data Science and Data Handling Ethics; 74 mappings; linked document v1.18.0; provenance and activity ranges for the new mappings.
- 1.2.0: Added clickable document labels, configurable document URL and linked document copies.
- 1.1.0: Added Zensical and Material for MkDocs integration documentation.
- 1.0.0: Initial package with FAIR IDs and short names, highlighting and ribbon details.
